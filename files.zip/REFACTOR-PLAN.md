# REFACTOR-PLAN.md

> **Wiederholbare Refactoring-Checkliste für den Personal Hub.**
> Diesen Plan kannst du immer wieder von vorne durchlaufen — jedes Mal, wenn die App
> ein Stück weitergewachsen ist. Phase 0 läuft nur einmal; Phase 1–4 sind der wiederholbare Zyklus.
>
> **Bedienung:** Claude Code öffnen → diese Datei @-mentionen → einen Durchlauf starten.
> Nach jedem Batch den Fortschritt unten im **Durchlauf-Log** eintragen, dann `/clear`.

---

## Wie dieser Plan zu benutzen ist

1. **Pro Batch eine frische Claude-Code-Session.** Kontext nie über ~60 % laufen lassen.
2. **Immer in einem Unterverzeichnis arbeiten** (z. B. `cd components/zeiterfassung`),
   nicht im Repo-Root — schärferer Fokus, Root-Kontext geht trotzdem nicht verloren.
3. **Jeder Batch endet mit einem grünen Test-Lauf + einem Commit.** Kein Commit ohne grüne Tests.
4. **Nach jedem Batch:** Durchlauf-Log unten ausfüllen → `/clear` → nächster Batch.

---

## Phase 0 — Harness (NUR EINMAL — danach abhaken und nie wieder)

> Wenn alle Boxen hier ✅ sind, überspringe Phase 0 bei zukünftigen Durchläufen komplett.

- [ ] **Root-`CLAUDE.md`** angelegt — enthält: npm als Package-Manager, Test-/Lint-/Build-Befehle,
      bekannte Baustellen (`/kunden` = Legacy, `/zeiterfassung2` = neue Variante,
      `CONCEPT.md` ≠ Implementierung), Satz „Use the simplest possible approach."
- [ ] **Gestaffelte `CLAUDE.md`** in mind. `lib/sync/` und `components/zeiterfassung/`
      (lokale Konventionen, modul-spezifische Stolperfallen).
- [ ] **`.claude/settings.json`** mit `permissions.deny` für `app/generated/prisma/**`,
      `node_modules/**`, `.next/**`.
- [ ] **Post-Edit-Hook** eingerichtet: `tsc --noEmit` + `eslint --fix` + `prettier --write`.
- [ ] **LSP / Code-Intelligence-Plugin** für TypeScript installiert.
- [ ] **Stop-Hook** (optional, empfohlen): schlägt am Session-Ende `CLAUDE.md`-Updates vor.
- [ ] Test-Setup steht (siehe `TESTING-PLAN.md`, Phase T0).

---

## Der wiederholbare Zyklus (Phase 1–4)

### Phase 1 — Kartieren (read-only, KEINE Änderungen)

Prompt an Claude Code (read-only Subagent verwenden):

```
Lies CLAUDE.md, DOCUMENTATION.md und CONCEPT.md.
Kartiere den aktuellen Zustand der Codebasis OHNE etwas zu ändern. Erstelle einen
Bericht und schreibe ihn nach docs/refactor/AUDIT-<DATUM>.md mit:

1. LOC-Ranking: die 15 längsten .ts/.tsx-Files (Pfad + Zeilenzahl).
2. Komplexitäts-Hotspots: Funktionen/Komponenten mit hoher zyklomatischer Komplexität.
3. Duplikate: Komponenten/Logik die mehrfach existieren oder sich stark überlappen.
4. Tote Pfade: Routen, Exports, Files die nirgends importiert/verlinkt werden.
5. Primitive-Bypass: Stellen die Spezial-Code nutzen statt kanban-board.tsx /
   sortable-table.tsx / detail-drawer / stats-grid.
6. Doku-Drift: Abweichungen zwischen CONCEPT.md / DOCUMENTATION.md und echtem Code.

Gib am Ende eine priorisierte Liste von Refactor-Batches aus (je 5-20 Files,
in sich geschlossen). Ändere NICHTS am Code.
```

- [ ] Audit-Bericht erstellt unter `docs/refactor/AUDIT-<DATUM>.md`.
- [ ] Batch-Liste aus dem Bericht unten in **Batch-Backlog** übertragen.

### Phase 2 — Charakterisierungs-Tests (für neue/ungetestete Module)

> Überspringe pro Modul, wenn dort schon Tests existieren und grün sind.

Für jedes Modul, das in diesem Durchlauf angefasst wird:

- [ ] Modul identifiziert, das refactored werden soll, aber noch keine Tests hat.
- [ ] Charakterisierungs-Tests von Claude Code generieren lassen, die das **aktuelle**
      Verhalten festschreiben (Rendering / Interaktionen / abgeleitete Werte / Side Effects).
- [ ] Tests laufen **grün gegen den ungeänderten Code** — das ist der Beweis, dass sie
      den Ist-Zustand korrekt einfangen.
- [ ] Commit: `test: charakterisierungs-tests für <modul>`.

Prompt-Vorlage:

```
Schreibe Charakterisierungs-Tests für <MODUL> (Pfad: <PFAD>).
Diese Tests sollen das AKTUELLE Verhalten festhalten — auch wenn es seltsam ist.
Ändere KEINEN Produktivcode. Decke ab:
- Rendering: Empty / Loading / Error / Normal-State
- Interaktionen: Klicks, Tippen, Keyboard, Selektion, Pagination
- Abgeleitete Werte: Summen, Filter-Counts, Formatierung, Disabled-States
- Side Effects: Speichern, URL-Updates, Focus
Die Tests müssen gegen den unveränderten Code grün laufen.
```

### Phase 3 — Refactorn (ein Batch nach dem anderen)

> **Pro Batch: frische Session.** Diesen Block für jeden Batch wiederholen.

Pro Batch:

- [ ] Frische Claude-Code-Session, ins relevante Unterverzeichnis gewechselt.
- [ ] Diesen Plan + den Audit-Bericht @-mentioned.
- [ ] Batch klar abgegrenzt (5–20 Files, ein Thema).
- [ ] Refactor durchgeführt — Verhalten unverändert, nur Struktur.
- [ ] Charakterisierungs-Tests laufen → **grün**.
- [ ] `tsc --noEmit` → keine Fehler. `eslint` → keine neuen Warnungen.
- [ ] `npm run build` → erfolgreich.
- [ ] Diff manuell reviewed (wie ein Junior-PR).
- [ ] Commit mit aussagekräftiger Message (`refactor: ...`).
- [ ] Durchlauf-Log unten ausgefüllt → `/clear`.

Prompt-Vorlage pro Batch:

```
Refactor-Batch: <BATCH-NAME>
Dateien: <LISTE, 5-20 Files>
Ziel: <z.B. "kanban-board.tsx als Primitive nutzen statt Spezial-Code">

Regeln:
- Verhalten darf sich NICHT ändern. Nur Struktur/Lesbarkeit/Wiederverwendung.
- Use the simplest possible approach — keine neuen Abstraktionen ohne Notwendigkeit.
- Lange Files in fokussierte Komponenten + Hooks aufteilen.
- Nach Abschluss: Charakterisierungs-Tests + tsc + build laufen lassen.
- Wenn ein Test rot wird: STOP, melde es, ändere die Tests NICHT eigenmächtig.
```

**Empfohlene Batch-Reihenfolge** (gilt für den ersten Durchlauf; bei späteren Durchläufen
ergibt sie sich aus dem Audit):

1. Duplikate auflösen — `kunden/` entfernen (von `clients/` abgelöst), `zeiterfassung2/`
   in `zeiterfassung/` mergen.
2. Die längsten Files aus dem LOC-Ranking in Komponenten + Hooks zerlegen.
3. Spezial-Code auf generische Primitives umstellen (`kanban-board`, `sortable-table`,
   `detail-drawer`, `stats-grid`).
4. `lib/`-Helper konsolidieren — Dubletten zwischen `lib/kunden/`, `lib/clients/`,
   `lib/mirror/` zusammenführen.

### Phase 4 — Doku angleichen (am Ende jedes Durchlaufs)

- [ ] `DOCUMENTATION.md` auf den realen Stand gebracht (Routen, Struktur, Models).
- [ ] `CONCEPT.md`: Drift markiert oder korrigiert (`VaultIndex`/`TimeEntry` vs.
      `VaultFileMirror` — entweder Konzept anpassen oder klar als "geplant, nicht live" kennzeichnen).
- [ ] `CLAUDE.md` / `AGENTS.md` aktualisiert — gelöschte Module raus, neue Konventionen rein.
- [ ] Audit-Bericht dieses Durchlaufs nach `docs/refactor/archive/` verschoben.

---

## Definition of Done — pro Durchlauf

Ein Durchlauf gilt als abgeschlossen, wenn:

- [ ] Alle geplanten Batches dieses Durchlaufs sind ✅ und committed.
- [ ] Gesamte Test-Suite ist grün (`npm run test`).
- [ ] `npm run build` ist erfolgreich.
- [ ] Keine `tsc`-Fehler, keine neuen Lint-Warnungen.
- [ ] Doku gibt den realen Stand wieder (Phase 4 ✅).
- [ ] Durchlauf-Log unten ist vollständig ausgefüllt.

---

## Batch-Backlog (aus dem jeweils aktuellen Audit befüllen)

| # | Batch-Name | Dateien (ca.) | Ziel | Status |
|---|---|---|---|---|
| 1 | _z. B. kunden→clients merge_ | | | ☐ offen |
| 2 | | | | ☐ offen |
| 3 | | | | ☐ offen |
| 4 | | | | ☐ offen |
| 5 | | | | ☐ offen |

---

## Durchlauf-Log

> Eine Zeile pro Batch. Bei jedem neuen Durchlauf einen neuen Abschnitt anlegen.

### Durchlauf 1 — gestartet am: __________

| Datum | Batch | Files geändert | Tests grün? | Commit-Hash | Notizen |
|---|---|---|---|---|---|
| | | | ☐ | | |
| | | | ☐ | | |
| | | | ☐ | | |

**Durchlauf 1 abgeschlossen am:** __________
**Erkenntnisse für nächsten Durchlauf:** _____________________________________

---

### Durchlauf 2 — gestartet am: __________

| Datum | Batch | Files geändert | Tests grün? | Commit-Hash | Notizen |
|---|---|---|---|---|---|
| | | | ☐ | | |

**Durchlauf 2 abgeschlossen am:** __________
**Erkenntnisse für nächsten Durchlauf:** _____________________________________

---

## Anti-Pattern-Checkliste — bei jedem Batch im Kopf behalten

- ❌ Batch zu groß ("refactor alles rund um X") → max. 5–20 Files, ein Thema.
- ❌ Commit ohne grüne Tests → niemals.
- ❌ Claude die Tests anpassen lassen, wenn sie rot werden → STOP, das ist ein echter Regressionsfund.
- ❌ Kontext über 60 % laufen lassen → vorher Fortschritt sichern + `/clear`.
- ❌ Neue Abstraktionen "auf Vorrat" → "simplest possible approach".
- ❌ Doku am Ende vergessen → Phase 4 ist Pflicht, sonst driftet alles wieder.
