# TESTING-PLAN.md

> **Test-Setup für den Personal Hub — von Null.**
> Geschrieben für jemanden, der noch nicht mit Testing gearbeitet hat.
> Begleitdokument zum `REFACTOR-PLAN.md` — die Tests aus diesem Plan sind das
> Sicherheitsnetz für das Refactoring.

---

## Empfohlenes Tool-Set

Für ein **Next.js (App Router) + React + TypeScript**-Projekt ist das der heute gängige
und beste Standard:

| Tool | Rolle | Warum |
|---|---|---|
| **Vitest** | Test-Runner | Schnell, native ESM- + TypeScript-Unterstützung ohne Config-Aufwand, Watch-Mode mit Instant-Feedback. Der moderne Standard. |
| **React Testing Library (RTL)** | Komponenten-Tests | Testet Komponenten so, wie ein Nutzer sie erlebt (Rollen, Labels, Text) — nicht Implementierungsdetails. Genau richtig für Charakterisierungs-Tests. |
| **@testing-library/jest-dom** | Zusätzliche Matcher | Lesbare Assertions wie `toBeInTheDocument()`, `toBeDisabled()`. |
| **@testing-library/user-event** | Interaktionen | Simuliert echte Nutzer-Aktionen (Klick, Tippen, Tab) realistischer als reines `fireEvent`. |
| **jsdom** | Browser-Umgebung | Stellt eine DOM-Umgebung im Node-Prozess bereit, damit Komponenten "rendern" können. |
| **Playwright** | End-to-End (E2E) | Für die wenigen echten Durchläufe (Login → Zeiteintrag → Sync) im echten Browser. Kommt **später**, nicht am Anfang. |

**Warum nicht Jest?** Jest ist der ältere Standard. Für ein modernes Setup ist Vitest die
empfohlene Wahl — du brauchst keinen PhD, um es zu konfigurieren: ein paar Zeilen Config
und die Tests laufen. RTL funktioniert mit beiden identisch — du verlierst also nichts.

> **Wichtiger Hinweis zum Tutorial unten:** Es nutzt ein reines **Vite**-Projekt, du hast
> aber **Next.js**. Die Test-*Konzepte* (`describe`, `it`, `render`, `screen`, Queries,
> `userEvent`) sind **1:1 identisch**. Nur die *Setup-Schritte* unterscheiden sich leicht.
> Deshalb steht das Next.js-Setup in Phase T0 unten explizit drin — folge für die Installation
> diesem Plan, und nutze das Video fürs Verständnis der Konzepte.

---

## Das Tutorial

**React Vite Testing Tutorial For Beginners — Vitest Testing Crash Course** (PedroTech)
🔗 https://www.youtube.com/watch?v=CxSL0knFxAs
⏱️ ~39 Minuten · 🇬🇧 Englisch

**Warum genau dieses:** Es geht von Null los — Vitest-Setup, dann praktische Beispiele für
UI-Komponenten, User-Interaktionen, Data Fetching und **Custom Hooks**. Custom Hooks ist
für dich besonders relevant (`use-timer`, `use-detail-drawer`, `use-background-save`).

**So schaust du es:** Einmal komplett durchschauen, ohne mitzucoden — Konzepte aufnehmen.
Dann ein zweites Mal, diesmal beim Mitcoden Phase T1 dieses Plans parallel offen halten.
Ignoriere die Vite-Projekt-Erstellung am Anfang — dein Setup steht in Phase T0.

**Begleitend zum Nachlesen** (kostenlos, sehr gut, deckt RTL-Queries und async im Detail ab):
Robin Wieruchs "React Testing Library Tutorial" — https://www.robinwieruch.de/react-testing-library/

---

## Test-Phasenplan

### Phase T0 — Setup (einmalig, ~30–45 Min)

Ziel: `npm run test` läuft und ein Dummy-Test ist grün.

- [ ] Pakete installieren:
  ```bash
  npm install -D vitest @vitejs/plugin-react jsdom \
    @testing-library/react @testing-library/jest-dom @testing-library/user-event
  ```
- [ ] `vitest.config.ts` im Projekt-Root anlegen:
  ```ts
  import { defineConfig } from "vitest/config";
  import react from "@vitejs/plugin-react";
  import path from "path";

  export default defineConfig({
    plugins: [react()],
    test: {
      environment: "jsdom",
      globals: true,
      setupFiles: ["./vitest.setup.ts"],
      css: true,
    },
    resolve: {
      alias: { "@": path.resolve(__dirname, ".") }, // passt @/-Imports an
    },
  });
  ```
- [ ] `vitest.setup.ts` im Projekt-Root anlegen:
  ```ts
  import "@testing-library/jest-dom/vitest";
  ```
- [ ] In `package.json` die Scripts ergänzen:
  ```json
  "scripts": {
    "test": "vitest",
    "test:run": "vitest run",
    "test:coverage": "vitest run --coverage"
  }
  ```
- [ ] Smoke-Test anlegen — `__tests__/smoke.test.ts`:
  ```ts
  import { describe, it, expect } from "vitest";

  describe("setup", () => {
    it("läuft", () => {
      expect(1 + 1).toBe(2);
    });
  });
  ```
- [ ] `npm run test` ausführen → der Smoke-Test ist **grün**. ✅

> Falls `@/`-Imports oder Server-Komponenten Probleme machen: das ist normal bei Next.js.
> Server Components / Server Actions werden **nicht** mit RTL getestet — die deckt Playwright
> in Phase T4 ab. RTL testet **Client-Komponenten** (`"use client"`) und **Hooks**.

### Phase T1 — Erste echte Komponenten-Tests (Übung, ~1–2 Std)

Ziel: Den Loop "rendern → abfragen → assertieren" verinnerlichen. Übe an einer **kleinen,
reinen** Komponente — kein Sync, kein GitHub. Gute Kandidaten in deinem Projekt:
`tag-input.tsx`, `stats-grid.tsx`, `components/loading/`.

- [ ] Eine kleine Client-Komponente auswählen.
- [ ] Test-Datei daneben anlegen: `tag-input.test.tsx`.
- [ ] Test schreiben, der prüft: Komponente rendert ohne Crash + zeigt erwarteten Text/Rolle.
- [ ] Test schreiben für eine Interaktion (z. B. Tag hinzufügen) mit `userEvent`.
- [ ] Beide grün. ✅

Grundgerüst, an dem du dich entlanghangeln kannst:
```tsx
import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { TagInput } from "@/components/tag-input";

describe("TagInput", () => {
  it("rendert das Eingabefeld", () => {
    render(<TagInput value={[]} onChange={() => {}} />);
    expect(screen.getByRole("textbox")).toBeInTheDocument();
  });

  it("fügt einen Tag bei Enter hinzu", async () => {
    const user = userEvent.setup();
    let tags: string[] = [];
    render(<TagInput value={tags} onChange={(t) => (tags = t)} />);
    await user.type(screen.getByRole("textbox"), "design{Enter}");
    expect(tags).toContain("design");
  });
});
```

**Faustregeln, die du aus dem Tutorial mitnehmen solltest:**
- Abfragen bevorzugt über **Rolle** (`getByRole`), dann **Label/Text** — nicht über CSS-Klassen.
- `getBy...` wenn das Element da sein muss, `queryBy...` wenn du Abwesenheit prüfst,
  `findBy...` für asynchron erscheinende Elemente.
- Teste **was der Nutzer sieht/tut**, nicht interne State-Variablen.

### Phase T2 — Custom Hooks testen (~1–2 Std)

Deine Hooks tragen viel Logik (`use-timer`, `use-detail-drawer`). Der Tutorial-Abschnitt
zu Custom Hooks zeigt das Muster mit `renderHook`.

- [ ] Einen Hook auswählen, der reine Logik kapselt (z. B. `use-timer`).
- [ ] Mit `renderHook` aus `@testing-library/react` testen.
- [ ] Start-/Stop-/Reset-Verhalten prüfen (`act()` für State-Updates nutzen).
- [ ] Grün. ✅

### Phase T3 — Charakterisierungs-Tests pro Modul (der eigentliche Zweck)

> Das ist die Verbindung zum `REFACTOR-PLAN.md`, Phase 2. **Erst diese Tests, dann refactorn.**

Für jedes Modul, das du refactorn willst, **bevor** du es anfasst:

- [ ] **Zeiterfassung** — Charakterisierungs-Tests: Quick-Entry rendert, Eintrag-Erstellung,
      Wochenansicht-Summen, Projekt-Filter.
- [ ] **Produkt-Ideen** — Kanban rendert mit Spalten, Karte verschieben ändert Status,
      Detail-Drawer öffnet/speichert.
- [ ] **Clients** — Liste rendert, Detailseite lädt, Verknüpfung mit Zeiterfassung.
- [ ] **Aufgaben** — Kanban-CRUD, Drawer-Background-Save.
- [ ] **Vault** — File-Tree rendert, Datei öffnen lädt Inhalt.

Wichtig: Diese Tests beschreiben den **Ist-Zustand**, auch wenn er nicht ideal ist.
Sie müssen **grün gegen den ungeänderten Code** laufen — das ist der Beweis, dass sie
das aktuelle Verhalten korrekt einfangen. Erst danach darf refactored werden.

Was pro Modul abgedeckt sein sollte:
- **Rendering:** Empty- / Loading- / Error- / Normal-State.
- **Interaktionen:** Klicks, Tippen, Keyboard-Nav, Selektion, Pagination.
- **Abgeleitete Werte:** Summen, gefilterte Counts, Formatierung, Disabled-States.
- **Side Effects:** Speichern, URL-Updates, Focus-Management.

Du musst diese Tests **nicht von Hand schreiben** — lass sie von Claude Code generieren
(Prompt-Vorlage steht im `REFACTOR-PLAN.md`, Phase 2). Deine Aufgabe ist: verstehen, was
sie tun, und prüfen, dass sie sinnvoll sind. Dafür brauchst du Phase T1–T2.

### Phase T4 — E2E mit Playwright (später, optional zu Beginn)

Erst sinnvoll, wenn die Unit-/Komponenten-Tests stehen. Deckt die paar echten
Nutzer-Durchläufe ab, die mehrere Module + echtes Routing berühren.

- [ ] `npm init playwright@latest` ausführen.
- [ ] Ein E2E-Test: Login → neuen Zeiteintrag anlegen → erscheint in der Wochenansicht.
- [ ] Ein E2E-Test: Produktidee anlegen → im Kanban sichtbar.

### Phase T5 — In den Workflow einbauen

- [ ] `npm run test` in den Post-Edit-Hook von Claude Code aufnehmen (siehe `REFACTOR-PLAN.md`
      Phase 0) — oder mindestens vor jedem Commit laufen lassen.
- [ ] Optional: GitHub Action, die `npm run test:run` bei jedem Push ausführt.
- [ ] Coverage gelegentlich prüfen (`npm run test:coverage`) — kein Zwang zu 100 %,
      aber die refactorten Module sollten solide abgedeckt sein.

---

## Was wird getestet — was nicht

| Testen mit RTL/Vitest | Nicht mit RTL testen |
|---|---|
| Client-Komponenten (`"use client"`) | Server Components (→ Playwright) |
| Custom Hooks | Server Actions direkt (→ Logik extrahieren + isoliert testen, oder Playwright) |
| Reine Logik-/Helper-Funktionen in `lib/` | Echte GitHub-API-Calls (→ mocken) |
| Abgeleitete Werte, Formatierung | Datenbank-Zugriffe (→ mocken) |

Externe Abhängigkeiten (GitHub API, Prisma, `fetch`) werden in Tests **gemockt** —
das Tutorial zeigt das Mocking-Muster im Data-Fetching-Abschnitt.

---

## Lern-Reihenfolge auf einen Blick

```
1. Tutorial einmal ansehen (~39 Min)            → Konzepte
2. Phase T0  Setup                              → npm run test läuft
3. Tutorial zweites Mal, mitcodend              → Festigung
4. Phase T1  kleine Komponente testen           → Loop verinnerlichen
5. Phase T2  einen Hook testen                  → renderHook-Muster
6. Phase T3  Charakterisierungs-Tests pro Modul → Sicherheitsnetz fürs Refactoring
7. → ab hier REFACTOR-PLAN.md Phase 3
8. Phase T4  Playwright (später)
9. Phase T5  in den Workflow einbauen
```

**Realistischer Zeitrahmen:** Phase T0–T2 an einem konzentrierten Nachmittag machbar.
Danach bist du bereit, die Charakterisierungs-Tests von Claude generieren zu lassen und
mit dem Refactoring zu starten.
