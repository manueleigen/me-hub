# Refactoring-Strategie — Personal Hub

> Leitfaden für die schrittweise Konsolidierung der Personal-Hub-App mit Claude Code.
> Begleitdokumente: `REFACTOR-PLAN.md` (wiederholbare Checkliste), `TESTING-PLAN.md` (Test-Setup von Null).

---

## Ausgangslage — ehrliche Einordnung

Das Projekt ist **nicht chaotisch**. Es hat eine durchdachte Basis: saubere Ordnertrennung
(`app/actions/`, `lib/sync/`, `components/[modul]/`), generische Primitives
(`kanban-board.tsx`, `sortable-table.tsx`), eine `AGENTS.md` und eine `DECISIONS.md`.

Die Probleme sind die typischen Symptome **organischen KI-Wachstums**:

1. **Zu lange, zu spezifische Files** — Spezial-Code statt Wiederverwendung der generischen Komponenten.
2. **Parallele Welten** — `kunden/` vs. `clients/`, `zeiterfassung/` vs. `zeiterfassung2/`.
3. **Konzept-Drift** — `CONCEPT.md` beschreibt `VaultIndex` / `TimeEntry`, live läuft `VaultFileMirror`.

Konsequenz: **Kein Big-Bang-Rewrite nötig.** Was es braucht, ist eine disziplinierte,
schrittweise Konsolidierung. Genau dafür ist Claude Code stark.

---

## Zwei Grundprinzipien

### 1. Harness vor Refactoring

Die Fähigkeiten von Claude Code werden **nicht allein durch das Modell** bestimmt — das
Ökosystem rund um das Modell (der "Harness") bestimmt die Performance mehr als das Modell allein.
Heißt: **Bevor eine Zeile refactored wird, baust du das Setup, das Claude Code beim sauberen
Arbeiten zwingt.** Das ist kein optionaler Schritt — er entscheidet über "gutes Produkt"
vs. "neues Chaos".

### 2. Planung schlägt Improvisation

Wenn Claude bei jeder Einzelentscheidung in 80 % der Fälle richtig liegt und ein Feature
20 Entscheidungspunkte hat, liegt die Wahrscheinlichkeit, dass alle stimmen, bei rund **1 %**.
Planung verwandelt 20 mehrdeutige Entscheidungen in eine geprüfte Spezifikation, bei der
jede Entscheidung bereits getroffen ist. Deshalb existiert `REFACTOR-PLAN.md`.

---

## Die Methode: Charakterisierungs-Tests als Sicherheitsnetz

Der zentrale Begriff für dieses Vorhaben heißt **Characterization Test**
(Begriff von Michael Feathers).

> Ein Charakterisierungs-Test dokumentiert, **was das System aktuell tut** — nicht,
> was es tun sollte.

Das klingt erst falsch, ist aber der Trick: Beim Refactoring sind diese Tests die Leitplanken.
Claude Code kann den Code umformen, aber **du entscheidest, was sich nicht ändern darf**.

Gerade bei React ist das essenziell, weil ein Refactor das Verhalten am häufigsten dann
ändert, wenn er versehentlich:

- **State zurücksetzt** — weil eine Komponentengrenze verschoben oder ein `key` geändert wurde.
- **ändert, wann Effects laufen** — weil Dependencies verschoben oder Mount/Unmount verändert wurden.
- **Memoization bricht** — sodass Handler/abgeleitete Werte bei jedem Render neu erzeugt werden.

Genau die Bugs, die beim Aufteilen langer Files drohen. Besonders kritisch bei diesem
Projekt: das `background save`-Pattern und der `SyncContext` — dort steckt Timing-Logik,
die ein naives Komponenten-Split leicht zerstört.

---

## Phasenplan

### Phase 0 — Harness aufsetzen (einmalig, vor allem anderen)

Die fünf Erweiterungspunkte, in der richtigen Reihenfolge:

| Schritt | Was | Warum |
|---|---|---|
| **CLAUDE.md zuerst** | Schlanke Root-`CLAUDE.md` + gestaffelte `CLAUDE.md` in `lib/sync/`, `components/zeiterfassung/` etc. | Claude liest sie automatisch zu Session-Beginn. Root = nur Verweise + kritische Stolperfallen. |
| **Hooks** | Post-Edit-Hook: `tsc --noEmit` + `eslint` + `prettier`. | Deterministische Checks sind verlässlicher als "Claude erinnert sich an eine Anweisung". |
| **`.claude/settings.json`** | `permissions.deny` für `app/generated/prisma/**`, `node_modules`, `.next`. | Versioniert → jeder bekommt dieselbe Rausch-Reduktion. Verhindert Unfälle. |
| **LSP-Integration** | Code-Intelligence-Plugin für TypeScript installieren. | Symbol-Suche statt String-Suche. Hoher Nutzen beim Auflösen von Duplikaten. |
| **MCP — zuletzt** | Bewusst weglassen, bis Phase 0–2 stehen. | Häufiger Fehler: MCP bauen, bevor die Basics funktionieren. |

**Wichtig für die Root-CLAUDE.md** — sie muss enthalten:
- Package-Manager (`npm`), Test-/Lint-/Build-Befehle.
- Die bekannten Baustellen **explizit benannt**: `/kunden` ist Legacy, `/zeiterfassung2`
  ist die neue Variante, `CONCEPT.md` ≠ Implementierung.
- Den Satz **„Use the simplest possible approach."** — wirkt erheblich gegen
  Over-Engineering (Claude fügt sonst verfrühte Abstraktionen hinzu).

> Hinweis zu CLAUDE.md über die Zeit: Instruktionen, die für das heutige Modell geschrieben
> wurden, können gegen ein zukünftiges arbeiten. Eine Regel wie „brich jeden Refactor in
> Einzeldatei-Änderungen auf" half früheren Modellen, würde ein neueres aber an koordinierten
> Cross-File-Edits hindern. → Setup alle 3–6 Monate prüfen.

### Phase 1 — Verstehen & kartieren (read-only)

Vor jeder Änderung eine Bestandsaufnahme — am besten über einen **Subagent** (isolierte
Claude-Instanz mit eigenem Kontextfenster: kartiert das Subsystem read-only und schreibt
die Ergebnisse in eine Datei; der Haupt-Agent editiert dann mit dem vollen Bild).

Abfragen: längste Files (LOC-Ranking), zyklomatische Komplexität pro Funktion, Duplikate,
tote Routen, Stellen mit dupliziertem Spezial-Code statt der generischen Primitives.
→ Ergebnis fließt in `REFACTOR-PLAN.md`.

### Phase 2 — Charakterisierungs-Tests schreiben

Erst jetzt — ebenfalls von Claude Code generiert. Pro Modul ein paar Tests, die festhalten:
- **Rendering** — Empty-, Loading-, Error-, Normal-State.
- **Interaktionen** — Klicks, Tippen, Keyboard-Nav, Selektion, Pagination.
- **Abgeleitete Werte** — Summen, gefilterte Counts, Formatierungen, Disabled-States.
- **Side Effects** — Analytics-Calls, Draft-Speichern, URL-Updates, Focus-Management.

Details im `TESTING-PLAN.md`.

### Phase 3 — Inkrementell refactorn

Streng in kleinen Batches. **Ziel: 5–20 Dateien, die eine logische, in sich geschlossene
Einheit bilden.**

- ✅ Guter Batch: „Refactor alle Authentication-Middleware-Files."
- ❌ Schlechter Batch: „Refactor alles rund um Users."

Pro Batch der Loop: spezifischer Auftrag → Claude refactored → Charakterisierungs-Tests
laufen → Diff reviewen → committen. **Jeden Diff wie den PR eines Junior-Entwicklers
behandeln.**

Sinnvolle Reihenfolge:
1. **Duplikate auflösen** (`kunden` löschen, `zeiterfassung2` mergen) — schrumpft die Codebasis sofort.
2. **Längste Files zerlegen** — in Komponenten + Hooks.
3. **Spezial-Code auf generische Primitives umstellen.**

### Phase 4 — Doku angleichen

`CONCEPT.md`, `DOCUMENTATION.md`, `AGENTS.md` / `CLAUDE.md` auf den realen Stand bringen.
Die Drift (`VaultIndex` vs. `VaultFileMirror`) darf am Ende nicht mehr existieren — sonst
führt sie Claude beim nächsten Mal wieder in die Irre.

---

## Kontext-Management — der praktische Killer

Egal wie gut der Plan: das hier killt sonst alles.

- Eine frische Session verbraucht ~20.000 Token.
- Qualität beginnt bei **20–40 %** des 200.000-Token-Fensters zu degradieren.
- Praxis-Konsens: **Kontext nicht über 60 % Kapazität** lassen.
- Auto-Compaction greift bei ~83,5 % und ist **verlustbehaftet** — behält nur ~20–30 % der Details.

**Lösung** — genau der Grund, warum der Plan im Repo liegt:
> Aktuellen Plan und Fortschritt in eine Markdown-Datei schreiben → `/clear` → frisch starten
> → Claude die Datei lesen lassen. Besser als `/compact`, weil du genau kontrollierst,
> was überlebt.

**Praktisch: pro Batch eine frische Session.** Plan-Datei rein, Batch machen,
Fortschritt zurückschreiben, `/clear`.

**Gegen den Instinkt:** Claude Code in **Unterverzeichnissen** initialisieren, nicht im
Repo-Root. Claude läuft den Verzeichnisbaum automatisch hoch und lädt jede `CLAUDE.md` —
Root-Kontext geht also nie verloren, aber der Fokus bleibt scharf.

---

## Tooling-Ergänzung

Ein zweiter, unabhängiger Reviewer (z. B. **Sourcery** oder **CodeRabbit**) ist sinnvoll —
nicht als Ersatz. Diese Tools scannen kontinuierlich nach dupliziertem Logik, ineffizienten
Funktionen und Inkonsistenzen. Der Kern bleibt aber: Claude Code für den Umbau,
deine Tests als Netz, dein Review als Gate.

---

## Qu-Zusammenfassung der Reihenfolge

```
Phase 0  Harness        → einmalig
Phase 1  Kartieren      → bei jedem Durchlauf (read-only Subagent)
Phase 2  Tests          → für neue/ungetestete Module
Phase 3  Refactorn      → in 5–20-Datei-Batches, frische Session pro Batch
Phase 4  Doku           → am Ende jedes Durchlaufs
```

Der `REFACTOR-PLAN.md` ist so gebaut, dass Phase 1–4 **immer wieder durchlaufen** werden
können, wenn die App weitergewachsen ist.
